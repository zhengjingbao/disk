package com.example.littlepangpang.surveyapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.*;
import android.os.Environment;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;


public class minorActivity11 extends AppCompatActivity {

    private TextView Tview=null;
    private RadioButton Rbutton=null;
    private CheckBox checkBox=null;
    private Button btn=null;
    private ListView LView=null;
    private RadioGroup genderGroup = null;
    private EditText   Etext=null;
    public int I=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minor11);
        /*Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void OnClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            });*/


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void button_click1(View view)
    {

        MainActivity.stringList[I]="";
        I++;
        Tview=(TextView)findViewById(R.id.textviewmain);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;

        Tview=(TextView)findViewById(R.id.textviewminor1);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        genderGroup=(RadioGroup)findViewById(R.id.radiobtngroupminor1) ;
        genderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radiogroup, int checkedId) {
                Rbutton=(RadioButton)findViewById(R.id.radiobtn1minor1);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;

                }
                else
                {
                    Rbutton=(RadioButton)findViewById(R.id.radiobtn2minor1);
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;

                }

            }
        });

        Tview=(TextView)findViewById(R.id.textviewminor2);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        checkBox=(CheckBox) findViewById(R.id.checkbox1minor2);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=checkBox.getText().toString();

                }
            }
        });
        checkBox=(CheckBox) findViewById(R.id.checkbox2minor2);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Tview.getText().toString();
                    I++;
                }
            }
        });
        checkBox=(CheckBox) findViewById(R.id.checkbox3minor2);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Tview.getText().toString();
                    I++;
                }
            }
        });
        checkBox=(CheckBox) findViewById(R.id.checkbox4minor2);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Tview.getText().toString();
                    I++;
                }
            }
        });


      /* Tview=(TextView)findViewById(R.id.textviewminor3);
        stringList.add("/n");
        stringList.add(Tview.getText());
        LView=(ListView)findViewById(R.id.listviewminor3) ;
        LView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                LView.getOnItemClickListener();
                stringList.add("/n");
                stringList.add(LView.getContext());

            }
        });*/


        Tview=(TextView)findViewById(R.id.textviewminor4);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        genderGroup=(RadioGroup)findViewById(R.id.radiobtngroupminor4) ;
        genderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radiogroup, int checkedId) {
                Rbutton=(RadioButton)findViewById(R.id.radiobtn1minor4);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn2minor4);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn3minor4);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I] = "/n";
                    I++;
                    MainActivity.stringList[I] = Rbutton.getText().toString();
                    I++;
                }

            }
        });

        Tview=(TextView)findViewById(R.id.textviewminor5);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        checkBox=(CheckBox) findViewById(R.id.checkbox1minor5);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=checkBox.getText().toString();
                    I++;
                }
            }
        });
        checkBox=(CheckBox) findViewById(R.id.checkbox2minor5);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=checkBox.getText().toString();
                    I++;
                }
            }
        });
        checkBox=(CheckBox) findViewById(R.id.checkbox3minor5);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=checkBox.getText().toString();
                    I++;
                }
            }
        });
        checkBox=(CheckBox) findViewById(R.id.checkbox4minor5);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=checkBox.getText().toString();
                    I++;
                }
            }
        });
        checkBox=(CheckBox) findViewById(R.id.checkbox5minor5);
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {

                if(isChecked){
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=checkBox.getText().toString();
                    I++;
                }
            }
        });

        Tview=(TextView)findViewById(R.id.textviewminor6);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        genderGroup=(RadioGroup)findViewById(R.id.radiobtngroupminor6) ;
        genderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radiogroup, int checkedId) {
                Rbutton=(RadioButton)findViewById(R.id.radiobtn1minor6);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I] = "/n";
                    I++;
                    MainActivity.stringList[I] = Rbutton.getText().toString();
                    I++;
                }
                Rbutton = (RadioButton) findViewById(R.id.radiobtn2minor6);
                if (Rbutton.isChecked() == true) {
                    MainActivity.stringList[I] = "/n";
                    I++;
                    MainActivity.stringList[I] = Rbutton.getText().toString();
                    I++;
                }
                Rbutton = (RadioButton) findViewById(R.id.radiobtn3minor6);
                if (Rbutton.isChecked() == true) {
                    MainActivity.stringList[I]= "/n";
                    I++;
                    MainActivity.stringList[I] = Rbutton.getText().toString();
                    I++;
                }
                Rbutton = (RadioButton) findViewById(R.id.radiobtn4minor6);
                if (Rbutton.isChecked() == true) {
                    MainActivity.stringList[I] = "/n";
                    I++;
                    MainActivity.stringList[I] = Rbutton.getText().toString();
                    I++;
                }
                Rbutton = (RadioButton) findViewById(R.id.radiobtn5minor6);
                if (Rbutton.isChecked() == true) {
                    MainActivity.stringList[I] = "/n";
                    I++;
                    MainActivity.stringList[I] = Rbutton.getText().toString();
                    I++;
                }


            }
        });

        Tview=(TextView)findViewById(R.id.textviewminor7);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        genderGroup=(RadioGroup)findViewById(R.id.radiobtngroupminor7) ;
        genderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radiogroup, int checkedId) {
                Rbutton=(RadioButton)findViewById(R.id.radiobtn1minor7);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn2minor7);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn3minor7);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn4minor7);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn5minor7);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }

            }
        });

        Tview=(TextView)findViewById(R.id.textviewminor8);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        genderGroup=(RadioGroup)findViewById(R.id.radiobtngroupminor8) ;
        genderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radiogroup, int checkedId) {
                Rbutton=(RadioButton)findViewById(R.id.radiobtn1minor8);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn2minor8);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn3minor8);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn4minor8);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }

            }
        });

        Tview=(TextView)findViewById(R.id.textviewminor9);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        genderGroup=(RadioGroup)findViewById(R.id.radiobtngroupminor9) ;
        genderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radiogroup, int checkedId) {
                Rbutton=(RadioButton)findViewById(R.id.radiobtn1minor9);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn2minor9);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn3minor9);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn4minor9);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }

            }
        });


        Tview=(TextView)findViewById(R.id.textviewminor10);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        genderGroup=(RadioGroup)findViewById(R.id.radiobtngroupminor10) ;
        genderGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radiogroup, int checkedId) {
                Rbutton=(RadioButton)findViewById(R.id.radiobtn1minor10);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn2minor10);
                if (Rbutton.isChecked() == true ) {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn3minor10);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }
                Rbutton=(RadioButton)findViewById(R.id.radiobtn4minor10);
                if (Rbutton.isChecked() == true )
                {
                    MainActivity.stringList[I]="/n";
                    I++;
                    MainActivity.stringList[I]=Rbutton.getText().toString();
                    I++;
                }

            }
        });

        Tview=(TextView)findViewById(R.id.textviewminor11);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Tview.getText().toString();
        I++;
        Etext=(EditText)findViewById(R.id.edittextminor11);
        MainActivity.stringList[I]="/n";
        I++;
        MainActivity.stringList[I]=Etext.getText().toString();
        I++;
        String database=MainActivity.stringList[I].toString();


        startActivity(new Intent(this, minorActivity12.class));


    }

}
